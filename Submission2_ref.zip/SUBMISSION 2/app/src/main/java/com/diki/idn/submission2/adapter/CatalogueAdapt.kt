package com.diki.idn.submission2.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.diki.idn.submission2.R
import com.diki.idn.submission2.model.Model
import kotlinx.android.synthetic.main.item_catalogue.view.*

class CatalogueAdapt(
    private val listMovie: ArrayList<Model>,
    private val listener: (Model) -> Unit
) : RecyclerView.Adapter<CatalogueAdapt.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.item_catalogue, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int = listMovie.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(listMovie[position], listener)
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(model: Model, listener: (Model) -> Unit) {
            with(itemView) {
                Glide.with(itemView.context)
                    .load(model.image)
                    .apply(
                        RequestOptions()
                            .override(
                                resources.getDimensionPixelSize(R.dimen.padding_hundred),
                                resources.getDimensionPixelSize(R.dimen.padding_hunddred_fifth)
                            )
                    ).into(iv_mov_poster)
                tv_mov_name.text = model.title
//                tv_mov_desc.text = model.description

                itemView.setOnClickListener { listener(model) }
            }
        }

    }

}
