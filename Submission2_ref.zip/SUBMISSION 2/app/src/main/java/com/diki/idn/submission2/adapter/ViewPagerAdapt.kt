package com.diki.idn.submission2.adapter

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.diki.idn.submission2.R
import com.diki.idn.submission2.fragment.MoviesFragment
import com.diki.idn.submission2.fragment.TVShowFragment

class ViewPagerAdapt(var context: Context, fm: FragmentManager) :
    FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    override fun getItem(position: Int): Fragment {
        when (position) {
            0 -> return MoviesFragment()
            1 -> return TVShowFragment()
        }
        return MoviesFragment()
    }

    override fun getCount(): Int {
        return 2
    }

    override fun getPageTitle(position: Int): CharSequence? {
        if (position == 0) {
            return context.getString(R.string.tab_text_one)
        } else if (position == 1) {
            return context.getString(R.string.tab_text_two)
        }
        return super.getPageTitle(position)
    }
}